/**
 * ═══════════════════════════════════════════════
 *   𝕵𝖊𝖗𝖊𝖒𝖎𝖊-𝟺  —  Bot WhatsApp (Baileys) — VPS
 *   15 catégories + chiffrement AES-256 des logs
 * ═══════════════════════════════════════════════
 */

require('dotenv').config()
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  Browsers,
  makeCacheableSignalKeyStore,
  downloadMediaMessage,
} = require('@whiskeysockets/baileys')
const pino = require('pino')
const fs = require('fs')
const path = require('path')
const readline = require('readline')
const axios = require('axios')
const crypto = require('crypto')

// ═══════════════ CONFIGURATION ═══════════════
const CONFIG = {
  botName: '𝕵𝖊𝖗𝖊𝖒𝖎𝖊-𝟺',
  ownerNumber: '22399944032', // ⚠️ REMPLACE par TON numéro (sans + ni espace)
  prefix: '!',
  adminPrefix: '.', // commandes crypto/admin
  antiDelayMs: 2000,
  scriptLink: 'https://github.com/toncompte/jeremie-15',
  OPENAI_API_KEY: '',
  GEMINI_API_KEY: '',
  PEXELS_API_KEY: '',
}

const DB_DIR = path.join(__dirname, 'database')
const LOGS_DIR = path.join(__dirname, 'logs')
const ASSETS_DIR = path.join(__dirname, 'assets')
const PREMIUM_FILE = path.join(DB_DIR, 'premium.json')
const SETTINGS_FILE = path.join(DB_DIR, 'settings.json')
const LOG_RECU_FILE = path.join(LOGS_DIR, 'logs_recu.txt')
const LOG_ENVOI_FILE = path.join(LOGS_DIR, 'logs_envoi.txt')
const MENU_IMAGE = path.join(ASSETS_DIR, 'menu.jpg')
const ENV_PATH = path.join(__dirname, '.env')

;[DB_DIR, LOGS_DIR, ASSETS_DIR].forEach(d => { if (!fs.existsSync(d)) fs.mkdirSync(d) })
if (!fs.existsSync(PREMIUM_FILE)) fs.writeFileSync(PREMIUM_FILE, '[]')
if (!fs.existsSync(SETTINGS_FILE)) {
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify({
    isPublic: true, autobio: false, autoread: false, selfMode: false,
    cryptoEnabled: true, antilink: {}, antibot: {}, antispam: {},
  }, null, 2))
}
if (!fs.existsSync(LOG_RECU_FILE)) fs.writeFileSync(LOG_RECU_FILE, '')
if (!fs.existsSync(LOG_ENVOI_FILE)) fs.writeFileSync(LOG_ENVOI_FILE, '')

// ═══════════════ DB HELPERS ═══════════════
function readJSON(f) { return JSON.parse(fs.readFileSync(f, 'utf-8')) }
function writeJSON(f, d) { fs.writeFileSync(f, JSON.stringify(d, null, 2)) }
function getPremium() { return readJSON(PREMIUM_FILE) }
function savePremium(l) { writeJSON(PREMIUM_FILE, l) }
function getSettings() { return readJSON(SETTINGS_FILE) }
function saveSettings(s) { writeJSON(SETTINGS_FILE, s) }

// ═══════════════ CHIFFREMENT AES-256-CBC ═══════════════
const ALGORITHM = 'aes-256-cbc'

// Charge la clé depuis .env, ou la génère si absente (affichée UNE seule fois)
function loadOrCreateKey() {
  let key = process.env.BOT_SECRET_KEY
  if (!key || key.trim() === '') {
    key = crypto.randomBytes(32).toString('hex')
    let content = fs.existsSync(ENV_PATH) ? fs.readFileSync(ENV_PATH, 'utf-8') : ''
    content = content.includes('BOT_SECRET_KEY=')
      ? content.replace(/BOT_SECRET_KEY=.*/g, `BOT_SECRET_KEY=${key}`)
      : content + `\nBOT_SECRET_KEY=${key}\n`
    fs.writeFileSync(ENV_PATH, content)
    console.log('\n🔑 ═══════════════════════════════════')
    console.log('🔑 CLÉ GÉNÉRÉE (affichée une seule fois) :')
    console.log(`🔑 ${key}`)
    console.log('🔑 Sauvegarde-la en lieu sûr !')
    console.log('🔑 ═══════════════════════════════════\n')
  }
  return Buffer.from(key, 'hex')
}
let SECRET_KEY = loadOrCreateKey()

function setKey(newKeyHex) {
  SECRET_KEY = Buffer.from(newKeyHex, 'hex')
  let content = fs.readFileSync(ENV_PATH, 'utf-8')
  content = content.includes('BOT_SECRET_KEY=')
    ? content.replace(/BOT_SECRET_KEY=.*/g, `BOT_SECRET_KEY=${newKeyHex}`)
    : content + `\nBOT_SECRET_KEY=${newKeyHex}\n`
  fs.writeFileSync(ENV_PATH, content)
}

// Chiffre un texte -> "iv:texteChiffré"
function encrypt(text) {
  const iv = crypto.randomBytes(16) // IV aléatoire à chaque appel
  const cipher = crypto.createCipheriv(ALGORITHM, SECRET_KEY, iv)
  let enc = cipher.update(String(text), 'utf8', 'hex')
  enc += cipher.final('hex')
  return `${iv.toString('hex')}:${enc}`
}
// Déchiffre "iv:texteChiffré" -> texte clair
function decrypt(payload) {
  const [ivHex, encHex] = payload.split(':')
  const decipher = crypto.createDecipheriv(ALGORITHM, SECRET_KEY, Buffer.from(ivHex, 'hex'))
  let dec = decipher.update(encHex, 'hex', 'utf8')
  dec += decipher.final('utf8')
  return dec
}

// Écrit une ligne de log, chiffrée si l'option est active
function writeLog(file, direction, jid, text) {
  const settings = getSettings()
  const timestamp = new Date().toISOString()
  const payload = settings.cryptoEnabled ? encrypt(text) : text
  fs.appendFileSync(file, `[${timestamp}] ${direction} ${jid} :: ${payload}\n`)
}

// ═══════════════ ANTI-BAN : file d'attente ═══════════════
let queue = Promise.resolve()
function sleep(ms) { return new Promise(r => setTimeout(r, ms)) }

// Envoie un message : le CONTENU CLAIR part sur WhatsApp,
// mais la trace écrite dans les logs est chiffrée (ou en clair si crypto désactivé).
function sendSafeMessage(sock, jid, text) {
  queue = queue.then(async () => {
    writeLog(LOG_ENVOI_FILE, 'ENVOYÉ', jid, text) // log chiffré
    await sock.sendMessage(jid, { text }) // envoi en clair à l'utilisateur
    await sleep(CONFIG.antiDelayMs)
  })
  return queue
}

// ═══════════════ HELPERS ═══════════════
function isOwner(senderJid) {
  const num = senderJid.split('@')[0].split(':')[0]
  return num === CONFIG.ownerNumber
}
function isPremium(senderJid) {
  const num = senderJid.split('@')[0]
  return getPremium().includes(num) || isOwner(senderJid)
}
function extractText(msg) {
  return (
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    msg.message?.imageMessage?.caption ||
    msg.message?.videoMessage?.caption ||
    ''
  )
}
function formatUptime(seconds) {
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = Math.floor(seconds % 60)
  return `${h}h ${m}m ${s}s`
}

// ═══════════════ AUTO-REPLY (Jérémie absent) ═══════════════
const lastGreeted = new Map()
const COOLDOWN_MS = 60 * 60 * 1000 // 1h entre deux messages auto au même contact
const MOTS_SALUTATION = ['salut', 'slt', 'bonjour', 'bjr', 'coucou', 'cv', 'ça va', 'sa va', 'hello', 'hi', 'yo']

function isGreeting(text) {
  const t = text.toLowerCase().trim()
  return MOTS_SALUTATION.some(mot => t === mot || t.startsWith(mot + ' ') || t.startsWith(mot + ','))
}
function shouldAutoReply(jid) {
  const last = lastGreeted.get(jid)
  if (!last || Date.now() - last > COOLDOWN_MS) {
    lastGreeted.set(jid, Date.now())
    return true
  }
  return false
}
const MESSAGE_ABSENCE = `👋 Salut ! Jérémie n'est pas disponible pour le moment.

Tu peux :
1️⃣ Taper *!menu* pour utiliser mes commandes automatiques en attendant
2️⃣ Attendre que Jérémie soit de retour pour te répondre en personne

Merci de ta patience ! 🙏`

// ═══════════════ DONNÉES FUN ═══════════════
const BLAGUES = [
  "Pourquoi les plongeurs plongent-ils toujours en arrière ? Parce que sinon ils tombent dans le bateau.",
  "Qu'est-ce qu'un crocodile qui surveille la pharmacie ? Un investigator.",
]
const CITATIONS = [
  "« La vie, c'est ce qui se passe pendant que tu es occupé à faire d'autres projets. »",
  "« Le succès, c'est se planter neuf fois et se relever dix. »",
]

// ═══════════════ MENU TEXTE (15 catégories) ═══════════════
function buildMenu() {
  const p = CONFIG.prefix
  return `┌─❍「 ${CONFIG.
  
  botName} 」
│ Owner : wa.me/${CONFIG.ownerNumber}
│ Préfixe : ${p}
│ Uptime : ${formatUptime(process.uptime())}
└─────────────

┌─❍「 PREMIUM 」
│ ${p}addprem  ${p}delprem  ${p}listprem
└─────────────
┌─❍「 ANIME 」
│ ${p}anime  ${p}join  ${p}quiz
└─────────────
┌─❍「 MODÉRATION 」
│ ${p}groupstatut  ${p}kick  ${p}promote  ${p}demote  ${p}mute
└─────────────
┌─❍「 CREATOR 」
│ ${p}google  ${p}sticker  ${p}toimg  ${p}ytmp4  ${p}ytmp3
└─────────────
┌─❍「 GROUPE 」
│ ${p}mute2  ${p}open  ${p}close  ${p}linkgroup  ${p}revoke  ${p}setdesc  ${p}setname
└─────────────
┌─❍「 IA 」
│ ${p}gpt  ${p}gemini  ${p}blackbox
└─────────────
┌─❍「 SETTINGS 」
│ ${p}public  ${p}private  ${p}autobio  ${p}autoread  ${p}self
└─────────────
┌─❍「 FUN 」
│ ${p}blague  ${p}citation  ${p}couple  ${p}lovecal  ${p}tiktok
└─────────────
┌─❍「 MÉDIA 」
│ ${p}play  ${p}video  ${p}image  ${p}pinterest  ${p}wallpaper  ${p}meme
└─────────────
┌─❍「 ANTI 」
│ ${p}antilink on/off  ${p}antibot on/off  ${p}antispam on/off
└─────────────
┌─❍「 UTILS 」
│ ${p}jid  ${p}ping  ${p}runtime  ${p}owner  ${p}script  ${p}speed
└─────────────
┌─❍「 SYSTEM CORE 」
│ ${p}menu  ${p}help  ${p}alive
└─────────────
┌─❍「 TÉLÉCHARGEMENT 」
│ ${p}facebook  ${p}instagram  ${p}tiktokdl
└─────────────
┌─❍「 ÉDUCATION 」
│ ${p}trad  ${p}wikipedia  ${p}calc  ${p}météo
└─────────────
┌─❍「 CRYPTO & SÉCURITÉ 」
│ .crypton  .cryptoff  .setkey (owner)
└─────────────`
}

// ═══════════════ CONNEXION BAILEYS ═══════════════
async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState('auth_info')
  const { version } = await fetchLatestBaileysVersion()

  const sock = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' })),
    },
    browser: Browsers.ubuntu('Chrome'),
  })

  if (!sock.authState.creds.registered) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
    const question = (q) => new Promise((res) => rl.question(q, res))
    let phoneNumber = await question('📱 Numéro WhatsApp avec indicatif (ex: 22300000000) : ')
    phoneNumber = phoneNumber.replace(/[^0-9]/g, '')
    rl.close()
    await sleep(3000)
    const code = await sock.requestPairingCode(phoneNumber)
    console.log(`\n🔑 CODE DE JUMELAGE : ${code}\n`)
  }

  sock.ev.on('creds.update', saveCreds)

  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect } = update
    if (connection === 'close') {
      const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut
      console.log('❌ Connexion fermée.', shouldReconnect ? 'Reconnexion...' : 'Déconnecté.')
      if (shouldReconnect) startBot()
    } else if (connection === 'open') {
      console.log(`✅ ${CONFIG.botName} est connecté !`)
    }
  })

  // ═══════════════ RÉACTION AUTOMATIQUE AUX STATUTS ═══════════════
  sock.ev.on('messages.upsert', async ({ messages }) => {
    const msg = messages[0]
    if (msg.key.remoteJid === 'status@broadcast' && !msg.key.fromMe) {
      try {
        await sock.readMessages([msg.key]) // vue du statut
        const emojis = ['❤️', '🔥', '👏', '😍', '👍']
        await sock.sendMessage('status@broadcast', {
          react: { text: emojis[Math.floor(Math.random() * emojis.length)], key: msg.key },
        }, { statusJidList: [msg.key.participant] })
      } catch (e) { console.error('Erreur réaction statut:', e.message) }
    }
  })

  // ═══════════════ RÉCEPTION DES MESSAGES ═══════════════
  sock.ev.on('messages.upsert', async ({ messages }) => {
    try {
      const msg = messages[0]
      if (!msg.message) return
      if (msg.key.remoteJid === 'status@broadcast') return

      const sender = msg.key.participant || msg.key.remoteJid
      const from = msg.key.remoteJid
      const isGroup = from.endsWith('@g.us')
      const text = extractText(msg).trim()
      const settings = getSettings()

      // Log du message REÇU (chiffré si activé)
      if (text) writeLog(LOG_RECU_FILE, 'REÇU', sender, text)

      if (settings.autoread) await sock.readMessages([msg.key])
      if (settings.selfMode && !isOwner(sender)) return
      if (!settings.isPublic && !isOwner(sender)) return

      // ── Auto-reply salutations (seulement en privé, pas dans les groupes) ──
      if (!isGroup && !msg.key.fromMe && text && isGreeting(text) && shouldAutoReply(from)) {
        await sendSafeMessage(sock, from, MESSAGE_ABSENCE)
      }

      if (!text.startsWith(CONFIG.prefix) && !text.startsWith(CONFIG.adminPrefix)) return

      const usedPrefix = text.startsWith(CONFIG.adminPrefix) ? CONFIG.adminPrefix : CONFIG.prefix
      const args = text.slice(usedPrefix.length).trim().split(/ +/)
      const command = args.shift().toLowerCase()
      const fullArgs = args.join(' ')
      const mentioned = msg.message.extendedTextMessage?.contextInfo?.mentionedJid || []
      const quoted = msg.message.extendedTextMessage?.contextInfo
      const reply = (t) => sendSafeMessage(sock, from, t)
      const groupMeta = isGroup ? await sock.groupMetadata(from).catch(() => null) : null
      const isAdmin = groupMeta?.participants.find(p => p.id === sender)?.admin != null
      const targetUser = mentioned[0] || quoted?.participant

      switch (command) {
        // ═══ CRYPTO & SÉCURITÉ (préfixe .) ═══
        case 'crypton': {
          if (!isOwner(sender)) return reply('⛔ Réservé à l\'owner.')
          settings.cryptoEnabled = true; saveSettings(settings)
          await reply('🔒 Chiffrage des logs ACTIVÉ.')
          break
        }
        case 'cryptoff': {
          if (!isOwner(sender)) return reply('⛔ Réservé à l\'owner.')
          settings.cryptoEnabled = false; saveSettings(settings)
          await reply('🔓 Chiffrage des logs DÉSACTIVÉ.')
          break
        }
        case 'setkey': {
          if (!isOwner(sender)) return reply('⛔ Réservé à l\'owner.')
          if (!fullArgs) return reply('Utilisation : .setkey [nouvelle_clé_hex_64_caractères]')
          try {
            setKey(fullArgs.trim())
            await reply('✅ Clé de chiffrage mise à jour.')
          } catch {
            await reply('❌ Clé invalide (doit être en hexadécimal, 64 caractères = 32 octets).')
          }
          break
        }

        // ═══ SYSTEM CORE ═══
        case 'menu':
        case 'help': {
          if (fs.existsSync(MENU_IMAGE)) {
            const buffer = fs.readFileSync(MENU_IMAGE)
            await sock.sendMessage(from, { image: buffer, caption: buildMenu() })
            await sleep(CONFIG.antiDelayMs)
          } else {
            await reply(buildMenu())
          }
          break
        }
        case 'alive':
          await reply(`✅ ${CONFIG.botName} est en ligne et opérationnel !`)
          break

        // ═══ PREMIUM ═══
        case 'addprem': {
          if (!isOwner(sender)) return reply('⛔ Réservé à l\'owner.')
          if (!targetUser) return reply('Mentionne un utilisateur.')
          const list = getPremium(); const num = targetUser.split('@')[0]
          if (list.includes(num)) return reply('Déjà premium.')
          list.push(num); savePremium(list)
          await reply(`✅ @${num} ajouté aux premium.`)
          break
        }
        case 'delprem': {
          if (!isOwner(sender)) return reply('⛔ Réservé à l\'owner.')
          if (!targetUser) return reply('Mentionne un utilisateur.')
          let list = getPremium(); const num = targetUser.split('@')[0]
          list = list.filter(n => n !== num); savePremium(list)
          await reply(`✅ @${num} retiré des premium.`)
          break
        }
        case 'listprem': {
          const list = getPremium()
          await reply(list.length ? `👑 Premium :\n${list.map(n => `• ${n}`).join('\n')}` : 'Aucun premium.')
          break
        }

        // ═══ MODÉRATION ═══
        case 'groupstatut':
          if (!isGroup) return reply('Groupe uniquement.')
          await reply(`📋 *${groupMeta.subject}*\nMembres : ${groupMeta.participants.length}`)
          break
        case 'kick':
          if (!isGroup || (!isAdmin && !isOwner(sender))) return reply('⛔ Admin uniquement.')
          if (!targetUser) return reply('Mentionne un utilisateur.')
          await sock.groupParticipantsUpdate(from, [targetUser], 'remove')
          await reply('✅ Expulsé.')
          break
        case 'promote':
          if (!isGroup || (!isAdmin && !isOwner(sender))) return reply('⛔ Admin uniquement.')
          if (!targetUser) return reply('Mentionne un utilisateur.')
          await sock.groupParticipantsUpdate(from, [targetUser], 'promote')
          await reply('✅ Promu admin.')
          break
        case 'demote':
          if (!isGroup || (!isAdmin && !isOwner(sender))) return reply('⛔ Admin uniquement.')
          if (!targetUser) return reply('Mentionne un utilisateur.')
          await sock.groupParticipantsUpdate(from, [targetUser], 'demote')
          await reply('✅ Rétrogradé.')
          break
        case 'mute':
          if (!isGroup || (!isAdmin && !isOwner(sender))) return reply('⛔ Admin uniquement.')
          await sock.groupSettingUpdate(from, 'announcement')
          await reply('🔇 Groupe muet.')
          break

        // ═══ CREATOR ═══
        case 'google': {
          if (!fullArgs) return reply('Utilisation : !google [recherche]')
          try {
            const { data } = await axios.get('https://api.duckduckgo.com/', { params: { q: fullArgs, format: 'json', no_html: 1 } })
            await reply(`🔎 ${data.AbstractText || data.RelatedTopics?.[0]?.Text || 'Aucun résultat.'}`)
          } catch { await reply('Erreur recherche.') }
          break
        }
        case 'sticker':
          await reply('🖼️ Branche ici sharp/ffmpeg pour la conversion image → sticker.')
          break
        case 'toimg':
          await reply('🖼️ Branche ici la conversion sticker → image.')
          break
        case 'ytmp4':
        case 'ytmp3': {
          if (!fullArgs) return reply(`Utilisation : !${command} [nom/lien]`)
          try {
            const ytSearch = require('yt-search')
            const r = await ytSearch(fullArgs)
            const v = r.videos[0]
            await reply(v ? `🎬 *${v.title}*\n${v.url}` : 'Rien trouvé.')
          } catch { await reply('Erreur.') }
          break
        }

        // ═══ GROUPE ═══
        case 'mute2':
        case 'close':
          if (!isGroup || (!isAdmin && !isOwner(sender))) return reply('⛔ Admin uniquement.')
          await sock.groupSettingUpdate(from, 'announcement')
          await reply('🔒 Groupe fermé.')
          break
        case 'open':
          if (!isGroup || (!isAdmin && !isOwner(sender))) return reply('⛔ Admin uniquement.')
          await sock.groupSettingUpdate(from, 'not_announcement')
          await reply('🔓 Groupe ouvert.')
          break
        case 'linkgroup': {
          if (!isGroup) return reply('Groupe uniquement.')
          const code = await sock.groupInviteCode(from)
          await reply(`🔗 https://chat.whatsapp.com/${code}`)
          break
        }
        case 'revoke':
          if (!isGroup || (!isAdmin && !isOwner(sender))) return reply('⛔ Admin uniquement.')
          await sock.groupRevokeInvite(from)
          await reply('✅ Lien révoqué.')
          break
        case 'setdesc':
          if (!isGroup || (!isAdmin && !isOwner(sender))) return reply('⛔ Admin uniquement.')
          await sock.groupUpdateDescription(from, fullArgs)
          await reply('✅ Description mise à jour.')
          break
        case 'setname':
          if (!isGroup || (!isAdmin && !isOwner(sender))) return reply('⛔ Admin uniquement.')
          await sock.groupUpdateSubject(from, fullArgs)
          await reply('✅ Nom mis à jour.')
          break

        // ═══ IA ═══
        case 'gpt': {
          if (!CONFIG.OPENAI_API_KEY) return reply('⚠️ Ajoute OPENAI_API_KEY dans CONFIG.')
          try {
            const { data } = await axios.post('https://api.openai.com/v1/chat/completions',
              { model: 'gpt-4o-mini', messages: [{ role: 'user', content: fullArgs }] },
              { headers: { Authorization: `Bearer ${CONFIG.OPENAI_API_KEY}` } })
            await reply(data.choices[0].message.content)
          } catch { await reply('Erreur GPT.') }
          break
        }
        case 'gemini': {
          if (!CONFIG.GEMINI_API_KEY) return reply('⚠️ Ajoute GEMINI_API_KEY dans CONFIG.')
          try {
            const { data } = await axios.post(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${CONFIG.GEMINI_API_KEY}`,
              { contents: [{ parts: [{ text: fullArgs }] }] })
            await reply(data.candidates[0].content.parts[0].text)
          } catch { await reply('Erreur Gemini.') }
          break
        }
        case 'blackbox':
          await reply('⚠️ Intègre ici l\'API Blackbox AI de ton choix.')
          break

        // ═══ SETTINGS ═══
        case 'public':
          if (!isOwner(sender)) return reply('⛔ Owner uniquement.')
          settings.isPublic = true; saveSettings(settings); await reply('🌍 Bot public.')
          break
        case 'private':
          if (!isOwner(sender)) return reply('⛔ Owner uniquement.')
          settings.isPublic = false; saveSettings(settings); await reply('🔒 Bot privé.')
          break
        case 'autobio':
          if (!isOwner(sender)) return reply('⛔ Owner uniquement.')
          settings.autobio = !settings.autobio; saveSettings(settings)
          await reply(`✅ Autobio ${settings.autobio ? 'activé' : 'désactivé'}.`)
          break
        case 'autoread':
          if (!isOwner(sender)) return reply('⛔ Owner uniquement.')
          settings.autoread = !settings.autoread; saveSettings(settings)
          await reply(`✅ Autoread ${settings.autoread ? 'activé' : 'désactivé'}.`)
          break
        case 'self':
          if (!isOwner(sender)) return reply('⛔ Owner uniquement.')
          settings.selfMode = !settings.selfMode; saveSettings(settings)
          await reply(`✅ Mode self ${settings.selfMode ? 'activé' : 'désactivé'}.`)
          break

        // ═══ FUN ═══
        case 'blague':
          await reply(BLAGUES[Math.floor(Math.random() * BLAGUES.length)])
          break
        case 'citation':
          await reply(CITATIONS[Math.floor(Math.random() * CITATIONS.length)])
          break
        case 'couple':
          await reply(`💞 Compatibilité : ${Math.floor(Math.random() * 101)}%`)
          break
        case 'lovecal':
          await reply(`❤️ Calcul amour : ${Math.floor(Math.random() * 101)}%`)
          break
        case 'tiktok': {
          if (!fullArgs) return reply('Utilisation : !tiktok [nom/lien]')
          try {
            const { data } = await axios.get('https://www.tikwm.com/api/', { params: { url: fullArgs } })
            await reply(data?.data?.play ? `🎵 ${data.data.play}` : 'Rien trouvé.')
          } catch { await reply('Erreur TikTok.') }
          break
        }

        // ═══ MÉDIA ═══
        case 'play':
        case 'video': {
          if (!fullArgs) return reply(`Utilisation : !${command} [nom]`)
          const ytSearch = require('yt-search')
          const r = await ytSearch(fullArgs)
          await reply(r.videos[0] ? `🎬 *${r.videos[0].title}*\n${r.videos[0].url}` : 'Rien trouvé.')
          break
        }
        case 'image': {
          if (!CONFIG.PEXELS_API_KEY) return reply('⚠️ Ajoute PEXELS_API_KEY dans CONFIG.')
          const { data } = await axios.get('https://api.pexels.com/v1/search',
            { params: { query: fullArgs, per_page: 1 }, headers: { Authorization: CONFIG.PEXELS_API_KEY } })
          const url = data.photos?.[0]?.src?.original
          if (url) { await sock.sendMessage(from, { image: { url } }); await sleep(CONFIG.antiDelayMs) }
          else await reply('Aucune image trouvée.')
          break
        }
        case 'wallpaper': {
          if (!CONFIG.PEXELS_API_KEY) return reply('⚠️ Ajoute PEXELS_API_KEY dans CONFIG.')
          const { data } = await axios.get('https://api.pexels.com/v1/curated',
            { params: { per_page: 1, page: Math.floor(Math.random() * 100) + 1 }, headers: { Authorization: CONFIG.PEXELS_API_KEY } })
          const url = data.photos?.[0]?.src?.original
          if (url) { await sock.sendMessage(from, { image: { url } }); await sleep(CONFIG.antiDelayMs) }
          break
        }
        case 'meme': {
          const { data } = await axios.get('https://meme-api.com/gimme')
          await sock.sendMessage(from, { image: { url: data.url }, caption: data.title })
          await sleep(CONFIG.antiDelayMs)
          break
        }
        case 'pinterest':
          await reply('⚠️ Intègre ici une API Pinterest de ton choix.')
          break

        // ═══ ANTI ═══
        case 'antilink':
        case 'antibot':
        case 'antispam': {
          if (!isGroup || (!isAdmin && !isOwner(sender))) return reply('⛔ Admin uniquement.')
          const state = args[0]?.toLowerCase()
          if (!['on', 'off'].includes(state)) return reply(`Utilisation : !${command} on/off`)
          settings[command][from] = state === 'on'; saveSettings(settings)
          await reply(`✅ ${command} ${state === 'on' ? 'activé' : 'désactivé'}.`)
          break
        }

        // ═══ ANIME ═══
        case 'anime': {
          if (!fullArgs) return reply('Utilisation : !anime [nom]')
          try {
            const { data } = await axios.get('https://api.jikan.moe/v4/anime', { params: { q: fullArgs, limit: 1 } })
            const a = data.data?.[0]
            await reply(a ? `📺 *${a.title}*\nÉpisodes : ${a.episodes || '?'}\nScore : ${a.score || '?'}` : 'Rien trouvé.')
          } catch { await reply('Erreur.') }
          break
        }
        case 'join': {
          if (!isOwner(sender)) return reply('⛔ Owner uniquement.')
          const code = fullArgs.split('/').pop()
          await sock.groupAcceptInvite(code)
          await reply('✅ Groupe rejoint.')
          break
        }
        case 'quiz':
          await reply('🎮 Quiz : Qui est le capitaine des Mugiwara ? (Réponds "Luffy")')
          break

       // ═══ VUE UNIQUE ═══
        case 'vv': {
          const quotedMsg = quoted?.quotedMessage
          const unwrapped =
            quotedMsg?.viewOnceMessageV2?.message ||
            quotedMsg?.viewOnceMessage?.message ||
            quotedMsg?.viewOnceMessageV2Extension?.message ||
            quotedMsg
          const mediaMsg = unwrapped?.imageMessage || unwrapped?.videoMessage
          if (!mediaMsg) return reply('Réponds à un message vue unique avec !vv')
          try {
            const buffer = await downloadMediaMessage(
              { key: msg.key, message: unwrapped },
              'buffer',
              {},
              { logger: pino({ level: 'silent' }), reuploadRequest: sock.updateMediaMessage }
            )
            if (unwrapped.imageMessage) {
              await sock.sendMessage(from, { image: buffer, caption: '🔓 Vue unique récupérée' })
            } else {
              await sock.sendMessage(from, { video: buffer, caption: '🔓 Vue unique récupérée' })
            }
            await sleep(CONFIG.antiDelayMs)
          } catch (e) {
            console.error(e)
            await reply('Erreur lors de la récupération du média.')
          }
          break
        }

        // ═══ TAG ALL ═══
        case 'tallg': {
          if (!isGroup) return reply('Commande de groupe uniquement.')
          if (!isAdmin && !isOwner(sender)) return reply('⛔ Réservé aux admins.')
          const participants = groupMeta.participants.map(p => p.id)
          const texte = fullArgs || '📢 Attention à tous !'
          let mentionText = `${texte}\n\n`
          participants.forEach(id => { mentionText += `@${id.split('@')[0]}\n` })
          await sock.sendMessage(from, { text: mentionText, mentions: participants })
          await sleep(CONFIG.antiDelayMs)
          break
        }
         // ═══ UTILS ═══
        case 'jid': await reply(`🆔 ${from}`); break
        case 'ping': await reply('🏓 Pong !'); break
        case 'runtime': await reply(`⏱️ Uptime : ${formatUptime(process.uptime())}`); break
        case 'owner': await reply(`👤 Owner : wa.me/${CONFIG.ownerNumber}`); break
        case 'script': await reply(`📜 ${CONFIG.scriptLink}`); break
        case 'speed': {
          const s = Date.now()
          await reply(`⚡ Vitesse : ${Date.now() - s}ms`)
          break
        }

        // ═══ TÉLÉCHARGEMENT ═══
        case 'tiktokdl': {
          if (!fullArgs) return reply('Utilisation : !tiktokdl [lien]')
          try {
            const { data } = await axios.get('https://www.tikwm.com/api/', { params: { url: fullArgs, hd: 1 } })
            await reply(data?.data?.play ? `✅ Sans filigrane :\n${data.data.play}` : 'Rien trouvé.')
          } catch { await reply('Erreur.') }
          break
        }
        case 'facebook':
          await reply('⚠️ Intègre ici une API tierce de téléchargement Facebook (clé requise).')
          break
        case 'instagram':
          await reply('⚠️ Intègre ici une API tierce de téléchargement Instagram (clé requise).')
          break

        // ═══ ÉDUCATION ═══
        case 'trad': {
          const lang = args[0]
          const texte = args.slice(1).join(' ')
          if (!lang || !texte) return reply('Utilisation : !trad [langue] [texte] (ex: !trad en Bonjour)')
          try {
            const { data } = await axios.get('https://api.mymemory.translated.net/get', { params: { q: texte, langpair: `fr|${lang}` } })
            await reply(`🌐 ${data.responseData.translatedText}`)
          } catch { await reply('Erreur traduction.') }
          break
        }
        case 'wikipedia': {
          if (!fullArgs) return reply('Utilisation : !wikipedia [recherche]')
          try {
            const { data } = await axios.get('https://fr.wikipedia.org/w/api.php', {
              params: { action: 'query', list: 'search', srsearch: fullArgs, format: 'json' },
            })
            const result = data.query.search[0]
            await reply(result ? `📖 *${result.title}*\n${result.snippet.replace(/<[^>]+>/g, '')}` : 'Rien trouvé.')
          } catch { await reply('Erreur Wikipedia.') }
          break
        }
        case 'calc': {
          if (!fullArgs || !/^[0-9+\-*/().\s]+$/.test(fullArgs)) return reply('Utilisation : !calc [opération] (chiffres et + - * / uniquement)')
          try {
            const result = Function(`"use strict"; return (${fullArgs})`)()
            await reply(`🧮 Résultat : ${result}`)
          } catch { await reply('Opération invalide.') }
          break
        }
        case 'météo':
        case 'meteo': {
          if (!fullArgs) return reply('Utilisation : !météo [ville]')
          try {
            const { data } = await axios.get(`https://wttr.in/${encodeURIComponent(fullArgs)}`, { params: { format: 3 } })
            await reply(`🌤️ ${data}`)
          } catch { await reply('Erreur météo.') }
          break
        }

        default:
          break
      }
    } catch (err) {
      console.error('Erreur handler:', err)
    }
  })

  // ═══════════════ ANTI-LIEN ═══════════════
  sock.ev.on('messages.upsert', async ({ messages }) => {
    const msg = messages[0]
    if (!msg.message || msg.key.remoteJid === 'status@broadcast') return
    const from = msg.key.remoteJid
    if (!from.endsWith('@g.us')) return
    const settings = getSettings()
    if (!settings.antilink?.[from]) return

    const text = extractText(msg)
    const sender = msg.key.participant
    if (/chat\.whatsapp\.com\/[a-zA-Z0-9]+/.test(text) && sender && !isOwner(sender)) {
      try {
        const groupMeta = await sock.groupMetadata(from)
        const isSenderAdmin = groupMeta.participants.find(p => p.id === sender)?.admin
        if (!isSenderAdmin) {
          await sock.sendMessage(from, { delete: msg.key })
          await sock.groupParticipantsUpdate(from, [sender], 'remove')
          await sendSafeMessage(sock, from, '🔗 Lien détecté → membre expulsé (antilink actif).')
        }
      } catch (e) { console.error(e) }
    }
  })

  return sock
}

startBot()